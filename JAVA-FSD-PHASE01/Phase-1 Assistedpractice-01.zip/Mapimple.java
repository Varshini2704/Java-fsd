package assistedpractice6;

	
import java.util.*;
public class Mapimple{
	
public static void main(String[] args) {
			
			HashMap<Integer,String> h=new HashMap<Integer,String>();      
		      h.put(1,"riya");    
		      h.put(2,"riyaz");    
		      h.put(3,"riyana");   
		       
		      System.out.println("\n Names of Hashmap");  
		      for(Map.Entry m:h.entrySet()){    
		       System.out.println(m.getKey()+" "+m.getValue());    
		      }
		     
		      Hashtable<Integer,String> h2=new Hashtable<Integer,String>();  
		      
		      h2.put(4,"anu");  
		      h2.put(5,"varshy");  
		      h2.put(6,"harsha");  
		      h2.put(7,"ayara");  

		      System.out.println("\nNames of HashTable");  
		      for(Map.Entry n:h2.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      TreeMap<Integer,String> m=new TreeMap<Integer,String>();    
		      m.put(8,"nira");    
		      m.put(9,"hina");    
		      m.put(10,"shika");       
		      
		      System.out.println("\nNames of TreeMap");  
		      for(Map.Entry l:m.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   }  
	}

